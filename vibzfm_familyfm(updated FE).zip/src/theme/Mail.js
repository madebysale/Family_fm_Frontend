import React from 'react'

export const Mail = () => {
  return (
    <div>Mail</div>
  )
}
